<?php
date_default_timezone_set('America/Lima');
session_start();
define('RUTA', 'http://localhost/shop/');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_NAME', 'shop');
define('DB_PASS', '');

define('CLIENT_ID_PAYPAL', 'ARtELM9gW5sQcYEDb-11-jdoPAig6Y--f9Ggu9-RStP0QO4QrECMBHzzQaownQd1lZCL4yoJEOmYo8CN');
?>